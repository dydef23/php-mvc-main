<?php

class User_model
{
    private $nama = 'Eko Wahyudi';

    public function getUser()
    {
        return $this->nama;
    }
}
